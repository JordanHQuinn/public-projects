package com.example.movienight;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Movie;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;
import java.util.Random;


public class MainActivity extends AppCompatActivity {
    TextView editTextMovie, editTextSnack, editTextSearchMovie, tvMovieNight;
    String[] myMovies = new String[50];
    String[] mySnacks = new String[50];
    private int numberOfMovies = 0;
    private int numberOfSnacks = 0;
    Random random = new Random(numberOfSnacks);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getViews();

    }

    public void onCreateMovieNight(View v) {
        String movie = searchMovies();
        MovieNightPlan movies = new MovieNightPlan(movie, mySnacks[random.nextInt(numberOfSnacks)]);
        tvMovieNight.setText(movies.toString());
    }
    public void onAddMovie(View v){
        String newMovie = editTextMovie.getText().toString();
        myMovies[numberOfMovies++] = newMovie;
        editTextMovie.setText("");
        System.out.println(myMovies);
    }

    public void onAddSnack(View v) {
        String newSnack = editTextSnack.getText().toString();
        mySnacks[numberOfSnacks++] = newSnack;
        editTextSnack.setText("");
        System.out.println(mySnacks);
    }

    private String searchMovies(){
        String search = editTextSearchMovie.getText().toString().toLowerCase();
        for (int i = 0; i < myMovies.length; i++) {
            if(myMovies[0].equals("")){
                break;
            } else {
                if(myMovies[i].toLowerCase().contains(search)){
                    return myMovies[i];
                }
            }
        }
            return "No movie";
    }

    public void getViews(){
        editTextMovie = findViewById(R.id.editTextMovie);
        editTextSnack = findViewById(R.id.editTextSnack);
        editTextSearchMovie = findViewById(R.id.editTextSearchMovie);
        tvMovieNight = findViewById(R.id.tvMovieNight);
    }
}