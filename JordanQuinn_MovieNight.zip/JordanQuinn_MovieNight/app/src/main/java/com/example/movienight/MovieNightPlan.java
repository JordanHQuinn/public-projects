package com.example.movienight;

public class MovieNightPlan {
    private String movie;
    private String snack;

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        if(movie.equals("")){
            throw new IllegalArgumentException("You have to have something");
        }
        this.movie = movie;
    }

    public String getSnack() {
        return snack;
    }

    public void setSnack(String snack) {
        if(snack.equals("")){
            throw new IllegalArgumentException("You have to have something");
        }
        this.snack = snack;
    }

    public MovieNightPlan(String movieName, String snackName){
        setMovie(movieName);
        setSnack(snackName);
    }

    public String toString(){
        return "The movie you will watch is " + getMovie() + " The snack you will eat is " + getSnack() + " enjoy your evening! If you get even more hungry though you can have more " + getSnack() + " as well.";

    }
}
