package com.example.personaltrainer;

public class Client {
    private String name;
    private int benchPress;
    private int squat;
    private int deadlift;
    private String actualResults;
    private int trainerGoalResults = 1000;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBenchPress() {
        return benchPress;
    }

    public void setBenchPress(int benchPress) {
        if(benchPress >= 900){
            this.benchPress = -1;
        } else {
        this.benchPress = benchPress;
        }
    }

    public int getSquat() {
        return squat;
    }

    public void setSquat(int squat) {
        if(squat >= 900){
            this.squat = -1;
        } else{
        this.squat = squat;
        }
    }

    public int getDeadlift() {
        return deadlift;
    }

    public void setDeadlift(int deadlift) {
        if(deadlift > 1400){
            this.deadlift = -1;
        } else {
            this.deadlift = deadlift;
        }
    }

    public String getActualResults() {
        return actualResults;
    }

    public void setActualResults(String actualResults) {
        this.actualResults = actualResults;
    }

    public int getTrainerGoalResults() {
        return trainerGoalResults;
    }

    public String lightWeight(int benchPress, int squat, int deadlift){
        String actualResults = "Good job! your total lifts added up to: " + benchPress + squat + deadlift + "Your trainer's goal for you was ";
        return actualResults;
    }


}
