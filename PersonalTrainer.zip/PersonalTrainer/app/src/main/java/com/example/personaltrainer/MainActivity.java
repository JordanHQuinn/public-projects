package com.example.personaltrainer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView editTextBenchPress, editTextSquat, editTextDeadlift, editTextName, textViewResults;
    Client client = new Client();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void onLift(View v){
        int sumOfLifts;
        getVariables();
        setVariables();
        client.lightWeight(client.getBenchPress(), client.getSquat(), client.getDeadlift());
        System.out.println(client.getBenchPress() + client.getSquat() + client.getDeadlift());
        sumOfLifts = client.getBenchPress() + client.getSquat() + client.getDeadlift();
        client.setActualResults("Good job " + client.getName() + "! your total lifts added up to: " + sumOfLifts + " Your trainer's goal for you was " + client.getTrainerGoalResults());
        System.out.println(client.getActualResults());
        textViewResults.setText(client.getActualResults());
    }

    public void getVariables(){
        editTextBenchPress = findViewById(R.id.editTextBenchPress);
        editTextSquat = findViewById(R.id.editTextSquat);
        editTextDeadlift = findViewById(R.id.editTextDeadlift);
        editTextName = findViewById(R.id.editTextName);
        textViewResults = findViewById(R.id.textViewResults);
    }

    public void setVariables(){
        client.setBenchPress(Integer.parseInt(editTextBenchPress.getText().toString()));
        client.setSquat(Integer.parseInt(editTextSquat.getText().toString()));
        client.setDeadlift(Integer.parseInt(editTextDeadlift.getText().toString()));
        client.setName(editTextName.getText().toString());
    }

}