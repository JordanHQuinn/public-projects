package com.example.jordanquinn_finalproject;

public class Zombie extends Human {
    private int attackPower = 20;

    @Override
    public int getAttackPower() {
        return attackPower;
    }

    @Override
    public void setAttackPower(int attackPower) {
        this.attackPower = attackPower;
    }

    public Zombie(int attackPower) {
        this.attackPower = attackPower;
    }
}
