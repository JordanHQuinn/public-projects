package com.example.jordanquinn_finalproject;

public class Team {
    public Human[] members = new Human[5];
    private int totalHP = 0;
    private int teamTotal = 0;

    public void addTeamMember(Human human){
        members[teamTotal] = human;
        teamTotal++;
    }

    public Human[] getMembers() {
        return members;
    }

    public void setMembers(Human[] members) {
        this.members = members;
    }

    public int getTotalHP() {
        return totalHP;
    }

    public void setTotalHP(int totalHP) {
        this.totalHP = totalHP;
    }

}
