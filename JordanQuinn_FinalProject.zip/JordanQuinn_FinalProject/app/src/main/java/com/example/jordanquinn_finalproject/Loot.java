package com.example.jordanquinn_finalproject;

public enum Loot {
    Nothing, Food, Water, Ammo, PocketSand, Zombie, Hat
}
