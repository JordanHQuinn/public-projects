package com.example.jordanquinn_finalproject;

public class Human {
    private String name;
    private int hp = 100;
    private String weapon;
    private int attackPower = 100;
    private Loot[] backpack = new Loot[25];
    private int turnNumber;

    public Human(String name, String weapon, int hp) {
        this.hp = 100;
        this.name = name;
        this.weapon = weapon;

    }

    public Human() {

    }

    public Human(int hp) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public String getWeapon() {
        return weapon;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }

    public int getAttackPower() {
        return attackPower;
    }

    public void setAttackPower(int attackPower) {
        this.attackPower = attackPower;
    }

    public Loot[] getBackpack() {
        return backpack;
    }

    public void setBackpack(Loot[] backpack) {
        this.backpack = backpack;
    }

    public int getTurnNumber() {
        return turnNumber;
    }

    public void setTurnNumber(int turnNumber) {
        this.turnNumber = turnNumber;
    }

    private Loot search(){
        switch(turnNumber){
            case 0:
                return Loot.valueOf("Hat");
            case 1:
                return Loot.valueOf("Nothing");

            case 2:
                return Loot.valueOf("Food");

            case 3:
                return Loot.valueOf("Water");

            case 4:
                return Loot.valueOf("Ammo");

            case 5:
                return Loot.valueOf("PocketSand");

            case 6:
                return Loot.valueOf("Zombie");
        }
        return Loot.valueOf("Nothing");
    }

    private String attack(){
        setHp(getHp() - getAttackPower());
        return "Attack";
    }

}
