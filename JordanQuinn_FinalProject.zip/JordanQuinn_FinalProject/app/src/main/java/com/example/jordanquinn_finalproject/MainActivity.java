package com.example.jordanquinn_finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private final int MAX_TEAM = 5;
    TextView etHumanName, etHumanWeapon, tvBackpackContents, tvAction, tvTeam, tvTeamTotalHealth;
    Button btnSearch, btnAddHuman, btnSkip, btnStartOver;
    private int teamNumber = 0;
    public int rollNumber = 0;
    Team team = new Team();
    Zombie zombie = new Zombie(20);
    String teamTotalHealth = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getView();
        startNewGame();
        tvAction.setText("You come across a neighborhood, do you want to search it or skip to the next area?");
    }

    public void onAdd(View v) {
        String showTeam;
        if (teamNumber >= MAX_TEAM) {
            throw new IllegalArgumentException("You can't have more than five in a team");
        } else {
            String name = etHumanName.getText().toString();
            String weapon = etHumanWeapon.getText().toString();
            System.out.println("Hello world");
            Human human = new Human();
            human.setName(name);
            human.setWeapon(weapon);
            human.setHp(100);
            showTeam = human.getName() + " " + human.getWeapon() + " Starting HP: " + human.getHp();
            System.out.println(human.getName() + human.getWeapon() + human.getHp());
            team.addTeamMember(human);
            team.setTotalHP(team.getTotalHP() + human.getHp());
            teamNumber++;
            System.out.println(teamNumber);
            etHumanName.setText("");
            etHumanWeapon.setText("");
            System.out.println(Arrays.toString(team.getMembers()));
            for (int i = 0; i < teamNumber; i++) {
                System.out.println(team.members[i].getName());
            }
            teamTotalHealth = "Team Total HP: " + team.getTotalHP();
            tvTeamTotalHealth.setText(teamTotalHealth);
        }

        showTeam = tvTeam.getText() + " " + showTeam + "\n";
        tvTeam.setText(showTeam);

    }

    public void onSearch(View v) {
        checkForLoss();
        System.out.println(this.rollNumber);

        if (teamNumber == 0) {
            throw new IllegalArgumentException("Team cannot be Zero!");
        } else {
            activeSearch();
        }
    }

    public void checkForLoss() {
        String action;
        if (team.getTotalHP() == 0) {
            action = "Game OVER YOU LOSE";
            tvAction.setText(action);
            btnSearch.setEnabled(false);
            btnAddHuman.setEnabled(false);
            btnSkip.setEnabled(false);
        }
    }


    public void onSkip(View v) {
        tvAction.setText("You quickly leave the area, and come across another neighborhood of houses.");
    }

    public void onStartOver(View v) {
        Team newTeam = new Team();
        tvAction.setText("");
        tvBackpackContents.setText("");
        tvTeam.setText("");
        tvTeamTotalHealth.setText("");
        startNewGame();
    }

    public int generateRandomNumber(int upperBound) {
        Random generator = new Random();

        return generator.nextInt(upperBound + 1);

    }

    public String activeSearch() {
        String backPack;
        String action;
        int rollNumber = generateRandomNumber(6);
        if (team.getTotalHP() <= 0) {
            action = "Game OVER YOU LOSE";
            tvAction.setText(action);
        }

            if (rollNumber == 0) {
                backPack = " " + tvBackpackContents.getText().toString() + " " + "\r";
                action = "You found Nothing";
                tvAction.setText(action);
                return backPack;

            }
            if (rollNumber == 1) {
                backPack = " " + tvBackpackContents.getText().toString() + " " + Loot.valueOf("Food").toString() + " " + "\r";
                tvBackpackContents.setText(backPack);
                action = "You found " + Loot.valueOf("Food").toString();
                tvAction.setText(action);

                return backPack;
            }
            if (rollNumber == 2) {
                backPack = " " + tvBackpackContents.getText().toString() + " " + Loot.valueOf("Water").toString() + " " + "\r";
                tvBackpackContents.setText(backPack);
                action = "You found " + Loot.valueOf("Water").toString();
                tvAction.setText(action);
                return backPack;
            }
            if (rollNumber == 3) {
                backPack = " " + tvBackpackContents.getText().toString() + " " + Loot.valueOf("Ammo").toString() + " " + "\r";
                tvBackpackContents.setText(backPack);
                action = "You found " + Loot.valueOf("Ammo").toString();
                tvAction.setText(action);
                return backPack;
            }
            if (rollNumber == 4) {
                backPack = " " + tvBackpackContents.getText().toString() + " " + Loot.valueOf("PocketSand").toString() + " " + "\r";
                tvBackpackContents.setText(backPack);
                action = "You found " + Loot.valueOf("PocketSand").toString();
                tvAction.setText(action);
                return backPack;
            }
            if (rollNumber == 5) {
                getAttacked();
//                backPack = " " + tvBackpackContents.getText().toString() + " " + "\r";
//                tvBackpackContents.setText(backPack);
//                action = "Zombie attack, bummer";
//                tvAction.setText(action);
//                return backPack;
            }
            if (rollNumber == 6) {
                backPack = " " + tvBackpackContents.getText().toString() + " " + Loot.valueOf("Hat").toString() + " " + "\r";
                tvBackpackContents.setText(backPack);
                action = "You found " + Loot.valueOf("Hat").toString();
                tvAction.setText(action);
                return backPack;
            } else {
                return "Hello, this shouldn't have happened";
            }
        }


    public String getAttacked() {
        String announcement;
        if (team.getTotalHP() <= 0) {
            announcement = "Game OVER YOU LOSE";
            tvAction.setText(announcement);
            return announcement;
        } else {
            team.setTotalHP(team.getTotalHP() - zombie.getAttackPower());
            announcement = "Zombie attacked! - 20 Hp. Hp remaining is: " + team.getTotalHP() + " " + team.members[0].getName() + " took the zombie out with their " + team.members[0].getWeapon();
            tvAction.setText(announcement);
            teamTotalHealth = "Total HP: " + team.getTotalHP();
            tvTeamTotalHealth.setText(teamTotalHealth);
            return announcement;
        }
    }

    public void getView() {
        etHumanName = findViewById(R.id.etHumanName);
        etHumanWeapon = findViewById(R.id.etHumanWeapon);
        tvBackpackContents = findViewById(R.id.tvBackpackContents);
        tvAction = findViewById(R.id.tvAction);
        tvTeam = findViewById(R.id.tvTeam);
        etHumanName = findViewById(R.id.etHumanName);
        tvTeamTotalHealth = findViewById(R.id.tvTeamTotalHealth);
        btnSearch = findViewById(R.id.btnSearch);
        btnSkip = findViewById(R.id.btnSkip);
        btnAddHuman = findViewById(R.id.btnAddHuman);
        btnStartOver = findViewById(R.id.btnStartOver);
    }

    public void startNewGame() {
        btnAddHuman.setEnabled(true);
        btnSearch.setEnabled(true);
        btnSkip.setEnabled(true);
    }
}
