package com.example.highroller;

public class Player {
    public String name;
    private int score;
    private int rollsRemaining;

    Player(int setScore, int setRollsRemaining){
        setRollsRemaining(3);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(name == null || name.equals("")){
            throw new IllegalArgumentException("You have to enter a name, or anything really, just not nothing.");
        }
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        if(score < 0 || score > 72){
        throw new IllegalArgumentException("That's not possible how did you do that?");
    }
        this.score = score;
    }

    public int getRollsRemaining() {
        return rollsRemaining;
    }

    public void setRollsRemaining(int rollsRemaining) {
        if(rollsRemaining < 0){
            throw new IllegalArgumentException("You can't have more than 3 turns");
        }
        this.rollsRemaining = rollsRemaining;
    }

}
