package com.example.highroller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView editTextPlayer1Name, editTextPlayer2Name, editTextPlayer3Name, tvPlayer1Score, tvPlayer2Score, tvPlayer3Score, tvResults;
    Button btn1, btn2, btn3, btn4;
    Die die1 = new Die();
    Die die2 = new Die();
    Die die3 = new Die();
    Die die4 = new Die();
    Player player1 = new Player(0, 3);
    Player player2 = new Player(0, 3);
    Player player3 = new Player(0, 3);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getTextViews();
        changeTurn(false, true, true);
    }

    public void onPlayer1Click(View v) {
        player1.setScore(player1.getScore() + getValue());
        System.out.println("New score is: " + player1.getScore());
        String result = "" + player1.getScore();
        tvPlayer1Score.setText(result);
        player1.setRollsRemaining(player1.getRollsRemaining() - 1);
        changeTurn(true, false, true);
    }
    public void onPlayer2Click(View v){
        player2.setScore(player2.getScore() + getValue());
        System.out.println("New score is: " + player2.getScore());
        String result = "" + player2.getScore();
        tvPlayer2Score.setText(result);
        player2.setRollsRemaining(player2.getRollsRemaining() - 1);
        changeTurn(true, true, false);
    }
    public void onPlayer3Click(View v){
        player3.setScore(player3.getScore() + getValue());
        System.out.println("New score is: " + player3.getScore());
        String result = "" + player3.getScore();
        tvPlayer3Score.setText(result);
        player3.setRollsRemaining(player3.getRollsRemaining() - 1);
        changeTurn(false, true, true);
        determineWinner();
    }


    public int getValue(){
        String button1 = "" + die1.rollDie();
        String button2 = "" + die2.rollDie();
        String button3 = "" + die3.rollDie();
        String button4 = "" + die4.rollDie();

        btn1.setText(button1);
        btn2.setText(button2);
        btn3.setText(button3);
        btn4.setText(button4);
        int currentRoll = die1.rollDie() + die2.rollDie() + die3.rollDie() + die4.rollDie();
        return currentRoll;
    }

    public void getTextViews(){
        editTextPlayer1Name = findViewById(R.id.editTextPlayer1Name);
        editTextPlayer2Name = findViewById(R.id.editTextPlayer2Name);
        editTextPlayer3Name = findViewById(R.id.editTextPlayer3Name);
        tvPlayer1Score = findViewById(R.id.tvPlayer1Score);
        tvPlayer2Score = findViewById(R.id.tvPlayer2Score);
        tvPlayer3Score = findViewById(R.id.tvPlayer3Score);
        tvResults = findViewById(R.id.tvResults);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
    }

    public void determineWinner(){
        if(player3.getRollsRemaining() == 0){
            checkForWinner();
            tvResults.setText(checkForWinner());
        }
    }

    public String checkForWinner(){
        setNames();
        String results = "You win";
        if(player1.getScore() > player2.getScore() && player1.getScore() > player3.getScore()){
            results = "you win " + player1.getName();
            tvResults.setText(results);
        } else if(player2.getScore() > player1.getScore() && player2.getScore() > player3.getScore()){
            results = "You win " + player2.getName();
        } else if(player3.getScore() > player1.getScore() && player3.getScore() > player2.getScore()){
            results = "You win " + player3.getName();
        } else{
            results = "there must have been a tie or something";
        }
        return results;
    }

    public void setNames(){
        player1.setName(editTextPlayer1Name.getText().toString());
        player2.setName(editTextPlayer2Name.getText().toString());
        player3.setName(editTextPlayer3Name.getText().toString());
    }

    public void changeTurn(boolean disablePlayer1, boolean disablePlayer2, boolean disablePlayer3){
        findViewById(R.id.btnPlayer1Roll).setEnabled(!disablePlayer1);
        findViewById(R.id.btnPlayer2Roll).setEnabled(!disablePlayer2);
        findViewById(R.id.btnPlayer3Roll).setEnabled(!disablePlayer3);
    }

}