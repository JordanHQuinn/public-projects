package com.example.highroller;

import java.util.Random;

public class Die {
    Random random = new Random();
    int number;

    public int rollDie(){
        number = random.nextInt((6 - 1 + 1) + 1);
        return number;
    }
}